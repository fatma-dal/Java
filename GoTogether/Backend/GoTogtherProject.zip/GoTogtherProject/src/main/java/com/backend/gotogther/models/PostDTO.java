package com.backend.gotogther.models;



import lombok.Data;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Data
public class PostDTO {

    private Long id;

    @NotBlank(message = "Departure location cannot be blank")
    @Size(max = 100, message = "Departure location must not exceed 100 characters")
    private String depart;

    private String destination;

    private String date;

    private String description;

    private int seats;

    private String luggage;

    private int price;

    private String car;
}

