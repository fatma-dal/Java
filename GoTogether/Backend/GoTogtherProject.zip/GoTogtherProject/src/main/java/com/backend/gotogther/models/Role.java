package com.backend.gotogther.models;


public enum Role {
	ROLE_USER,
	ROLE_DRIVER,
	ROLE_ADMIN;
}
