package com.backend.gotogther;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoTogtherProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
